angular.module('app.controllers', [])
  
.controller('homeCtrl', function($scope) {

	$scope.noticias= 'Novas notícias!';
	console.log("Olá Cambada!");
	$scope.listaNoticias = 
		[
			{
		    "userId": "Bruno",
		    "id": 1,
		    "title": "Titulo da notícia",
		    "body": "blablablablablabla"
		  },
		  {
		    "userId": "Roseli",
		    "id": 2,
		    "title": "Titulo da notícia",
		    "body": "est rerum tempore vitae\nsequi sint nihil reprehenderit dolor beatae ea dolores neque\nfugiat blanditiis voluptate porro vel nihil molestiae ut reiciendis\nqui aperiam non debitis possimus qui neque nisi nulla"
		  },
		  {
		    "userId": "Rafael",
		    "id": 3,
		    "title": "Titulo da notícia",
		    "body": "et iusto sed quo iure\nvoluptatem occaecati omnis eligendi aut ad\nvoluptatem doloribus vel accusantium quis pariatur\nmolestiae porro eius odio et labore et velit aut"
		  },
		  {
		    "userId": "José",
		    "id": 3,
		    "title": "Titulo da notícia",
		    "body": "et iusto sed quo iure\nvoluptatem occaecati omnis eligendi aut ad\nvoluptatem doloribus vel accusantium quis pariatur\nmolestiae porro eius odio et labore et velit aut"
		  },
		  {
		    "userId": "Anderson",
		    "id": 4,
		    "title": "Titulo da notícia",
		    "body": "ullam et saepe reiciendis voluptatem adipisci\nsit amet autem assumenda provident rerum culpa\nquis hic commodi nesciunt rem tenetur doloremque ipsam iure\nquis sunt voluptatem rerum illo velit"
		  }
  	];

})
   
.controller('adicionarVeCuloCtrl', function($scope) {



	
	$scope.listaMarcas = 
		[
			{
		    "cd_marca_veiculo": 1,
		    "nm_marca_veiculo": "GM Chevrolet"
		  },
		  {
		    "cd_marca_veiculo": 2,
		    "nm_marca_veiculo": "Fiat"
		  },
		  {
		    "cd_marca_veiculo": 3,
		    "nm_marca_veiculo": "Volkswagem "
		  },
		  {
		    "cd_marca_veiculo": 4,
		    "nm_marca_veiculo": "Ford "
		  }
		 
  	];

  	$scope.listaChevrolet = 
		[
			{
		    "cd_modelo_veiculo": 1,
		    "nm_modelo_veiculo": "Onix"
		  },
		  {
		    "cd_modelo_veiculo": 2,
		    "nm_modelo_veiculo": "Celta"
		  },
		  {
		    "cd_modelo_veiculo": 3,
		    "nm_modelo_veiculo": "Prisma"
		  }
		 
  	];

  	$scope.listaVolkswagem = 
		[
			{
		    "cd_modelo_veiculo": 1,
		    "nm_modelo_veiculo": "Gol"
		  },
		  {
		    "cd_modelo_veiculo": 2,
		    "nm_modelo_veiculo": "Fox"
		  },
		  {
		    "cd_modelo_veiculo": 3,
		    "nm_modelo_veiculo": "Voyage"
		  }
		 
  	];

  	$scope.listaFiat = 
		[
			{
		    "cd_modelo_veiculo": 1,
		    "nm_modelo_veiculo": "Uno"
		  },
		  {
		    "cd_modelo_veiculo": 2,
		    "nm_modelo_veiculo": "Punto"
		  },
		  {
		    "cd_modelo_veiculo": 3,
		    "nm_modelo_veiculo": "Palio"
		  }
		 
  	];

  	$scope.listaFord = 
		[
			{
		    "cd_modelo_veiculo": 1,
		    "nm_modelo_veiculo": "Focus"
		  },
		  {
		    "cd_modelo_veiculo": 2,
		    "nm_modelo_veiculo": "Ecosport"
		  },
		  {
		    "cd_modelo_veiculo": 3,
		    "nm_modelo_veiculo": "Fiesta"
		  }
		 
  	];



  	 if($scope.selectedMarca = "GM Chevrolet" ){
	       $scope.listaModelo = $scope.listaChevrolet ;
	   }
	   else if($scope.selectedMarca = "Fiat" ){
	     $scope.listaModelo = $scope.listaFiat ;
	   }
	   else if($scope.selectedMarca = "Volkswagem" ){
	     $scope.listaModelo = $scope.listaVolkswagem ;
	   }
	   else if($scope.selectedMarca = "Ford" ){
	     $scope.listaModelo = $scope.listaFord ;
	   }

	

})
   
.controller('minhaContaCtrl', function($scope) {

})
   
.controller('hodMetroCtrl', function($scope) {

})
   
.controller('manutenEsCtrl', function($scope) {

	$scope.manutencao= 'Manutenção!';
	$scope.listaManutencao = 
		[
			{
		    "cd_manutencao": 1,
		    "nm_tipo_manutencao": "Substituir óleo do motor"
		  },
		  {
		    "cd_manutencao": 2,
		    "nm_tipo_manutencao": "Substituir filtro de óleo"
		  },
		  {
		    "cd_manutencao": 3,
		    "nm_tipo_manutencao": "Trocar filtro de combustível"
		  },
		  {
		    "cd_manutencao": 4,
		    "nm_tipo_manutencao": "Correia: Verificar estado"
		  }
		 
  	];

})
   
.controller('calculadoraFlexCtrl', function($scope) {
    
  // $scope.etanol = ""; 
  // $scope.gasolina = ""; 
  // $scope.melhor = "";

	$scope.calcular = function() {
		
		//console.log("Funcao");
	   var g = document.getElementById("g").value;
	   var e = document.getElementById("e").value;
	   // var g = $scope.gasolina;
		//var e = $scope.etanol;
		  if(e == "" || g == ""){
	      $scope.melhor = "Preencha os campos" ;
	  }
	   else if(e <= g*0.7){
	      $scope.melhor = "Abasteça com etanol" ;

	   }
	   else{
	      $scope.melhor = "Abasteça com gasolina" ;
	   }

	  // console.log($scope.melhor);
	}
})
   
.controller('alterarSenhaCtrl', function($scope) {

})
   
.controller('criarContaCtrl', function($scope) {

})
   
.controller('excluirContaCtrl', function($scope) {

})
         
.controller('loginCtrl', function($scope,$ionicSideMenuDelegate) {

//Disable sidemenu before login
   $scope.$on('$ionicView.enter', function () {
        $ionicSideMenuDelegate.canDragContent(false);
    });


})
   
.controller('notificaEsCtrl', function($scope) {

})
   
.controller('pageCtrl', function($scope) {

})
 